# 第2次隨堂-隨堂-QZ2
>
>學號：111111224
><br />
>姓名：邱武昱
><br />
>作業撰寫時間：30 (mins，包含程式撰寫時間)
><br />
>最後撰寫文件日期：2023/11/19
>

本份文件包含以下主題：(至少需下面兩項，若是有多者可以自行新增)
- [x] 說明內容
- [x] 個人認為完成作業須具備觀念

## 說明程式與內容
將亞東科技大學簡介改成h1
```csharp
<h1>  亞東科大簡介</h1>
```
將兩個更多按鈕連結到指定位置
```csharp
<li><a href="a" class="button">更多...</a></li>
<li><a href="b" class="button">更多...</a></li>
```
將4個icon連結到對應網站
```csharp
<li><a href="https://twitter.com/home" class="icon brands fa-twitter"><span class="label">Twitter</span></a></li>
<li><a href="https://github.com/" class="icon brands fa-github"><span class="label">Github</span></a></li>
<li><a href="https://dribbble.com/" class="icon brands fa-dribbble"><span class="label">Dribbble</span></a></li>
<li><a href="https://www.google.com.tw" class="icon solid fa-envelope"><span class="label">Email</span></a></li>
```
更改圖片與縮圖
```csharp
<a href="images/Base/01.jpg" class="image fit thumb"><img src="images/Base/thumbs/01.jpg" alt="" /></a>
<a href="images/Base/02.jpg" class="image fit thumb"><img src="images/Base/thumbs/02.jpg" alt="" /></a>
<a href="images/Base/03.jpg" class="image fit thumb"><img src="images/Base/thumbs/03.jpg" alt="" /></a>
<a href="images/Base/04.jpg" class="image fit thumb"><img src="images/Base/thumbs/04.jpg" alt="" /></a>
<a href="images/Base/05.jpg" class="image fit thumb"><img src="images/Base/thumbs/05.jpg" alt="" /></a>
<a href="images/Base/06.jpg" class="image fit thumb"><img src="images/Base/thumbs/06.jpg" alt="" /></a>
```
更改連絡報名的文字框，滑鼠滑過去會改顏色
```csharp
#name:hover,#email:hover,#message:hover{
	background-color: #3eb08f;
}
```
## 個人認為完成作業須具備觀念
需要理解git的基本操作，html的常用標籤等等，還需要知道css屬性的使用方法，一切都熟悉過後，想信完成這份作業不是什麼難事。